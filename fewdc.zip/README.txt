FOR GITHUB
https://github.com/snailsquid/fewdc

Working Website
https://kakha.vercel.app/